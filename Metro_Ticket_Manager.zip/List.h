#ifndef LIST_H
#define LIST_H
#include <iostream>
#include <string>
#include "Structs.h"
using namespace std;
template <typename T>
class List{
public:
    T *head, *tail;
    int size;
    List(){
        head=tail=NULL;
        size=0;
    }
    void addLast(T *p){
        if(p==NULL){
            cout<<"Cap phat du lieu loi !"<<endl;
            return;
        }else if(head==NULL){
            head=tail=p;
        }else{
            tail->next=p;
            tail=p;
        }
        size++;
    }
    void inputPassenger();
    void showPassenger();
    void deletePassenger();
    void updatePassenger();
    Passenger *searchPassenger(List<Passenger>& list, int id);
    void inputTicket(List<Passenger>& passengerList,
                     List<Tickettype>& ticketTypeList,
                     List<Trip>& tripList,
                     List<Staff>& staffList,
                     List<Counter>& counterList);
    void showTicket(List<Passenger>& passengerList,
                    List<Tickettype>& ticketTypeList,
                    List<Trip>& tripList,
                    List<Staff>& staffList,
                    List<Counter>& counterList);
    void deleteTicket();
    void updateTicket(List<Passenger>& passengerList,
                    List<Tickettype>& ticketTypeList,
                    List<Trip>& tripList,
                    List<Staff>& staffList,
                    List<Counter>& counterList);
    void inputTickettype();
    void showTickettype();
    void deleteTickettype();
    void updateTickettype();
    Tickettype *searchTickettype(List<Tickettype>& list, int id);
    void inputTrip(List<Station>& stationList);
    void showTrip(List<Station>& stationList);
    void deleteTrip();
    void updateTrip(List<Station>& stationList);
    Trip *searchTrip(List<Trip>& list, int id);
    void inputStation();
    void showStation();
    void deleteStation();
    void updateStation();
    Station *searchStation(List<Station>& list, int id);
    void inputTransaction();
    void showTransaction();
    void deleteTransaction();
    void updateTransaction();
    void inputStaff();
    void showStaff();
    void deleteStaff();
    void updateStaff();
    Staff *searchStaff(List<Staff>& list, int id);
    void inputCounter();
    void showCounter();
    void deleteCounter();
    void updateCounter();
    Counter *searchCounter(List<Counter>& list, int id);
    void printTicket(List<Passenger>& passengerList,
                          List<Tickettype>& ticketTypeList,
                          List<Trip>& tripList,
                          List<Staff>& staffList,
                          List<Counter>& counterList,
                          List<Station>& stationList,
                          List<Ticket>& ticketList);
    void details(List<Passenger>& passengerList,
                List<Ticket>& ticketList,
                List<Tickettype>& ticketTypeList,
                List<Staff>& staffList,
                List<Station>& stationList);
    void merge(T* a[], int l, int m, int r);
    void mergesort(T* a[], int l, int r);
    void sortName();
};
#include "Functions.inl"
#endif