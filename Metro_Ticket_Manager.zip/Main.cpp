#include "List.h"
int main(){
    List<Passenger> passengerList;
    List<Staff> staffList;
    List<Trip> tripList;
    List<Station> stationList;
    List<Tickettype> ticketTypeList;
    List<Ticket> ticketList;
    List<Counter> counterList;
    List<Transaction> transactionList;
    int option;
    do{
        cout<<"==============================================\n";
        cout<<"|   CHUONG TRINH QUAN LY VE TAU DIEN METRO   |\n";
        cout<<"==============================================\n";
        cout<<"|1. Xem hanh khach                           |\n";
        cout<<"|2. Xem ve                                   |\n";
        cout<<"|3. Xem loai ve                              |\n";
        cout<<"|4. Xem luot di                              |\n";
        cout<<"|5. Xem ga tau                               |\n";
        cout<<"|6. Xem giao dich                            |\n";
        cout<<"|7. Xem nhan vien                            |\n";
        cout<<"|8. Xem quay ban ve                          |\n";
        cout<<"|9. Truy xuat ve                             |\n";
        cout<<"|10. Thong ke                                |\n";
        cout<<"|11. Tim kiem                                |\n";
        cout<<"|0. Thoat                                    |\n";
        cout<<"==============================================\n";
        cout<<"Chon: ";
        cin>>option;
        if(option==1){
            int option1;
            do{
                passengerList.showPassenger();
                cout<<"==============================================\n";
                cout<<"1. Them hanh khach\n";
                cout<<"2. Xoa hanh khach\n";
                cout<<"3. Chinh sua hanh khach\n";
                cout<<"4. Xem danh sach da sap xep\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    passengerList.inputPassenger();
                }else if(option1==2){
                    passengerList.deletePassenger();
                }else if(option1==3){
                    passengerList.updatePassenger();
                }else if(option1==4){
                    passengerList.sortName();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==2){
            int option1;
            do{
                ticketList.showTicket(passengerList, 
                                    ticketTypeList, 
                                    tripList, 
                                    staffList, 
                                    counterList);
                cout<<"==============================================\n";
                cout<<"1. Them ve\n";
                cout<<"2. Xoa ve\n";
                cout<<"3. Chinh sua ve\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    ticketList.inputTicket(passengerList, 
                                            ticketTypeList, 
                                            tripList, 
                                            staffList, 
                                            counterList);
                }else if(option1==2){
                    ticketList.deleteTicket();
                }else if(option1==3){
                    ticketList.updateTicket(passengerList, 
                                            ticketTypeList, 
                                            tripList, 
                                            staffList, 
                                            counterList);
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==3){
            int option1;
            do{
                ticketTypeList.showTickettype();
                cout<<"==============================================\n";
                cout<<"1. Them loai ve\n";
                cout<<"2. Xoa loai ve\n";
                cout<<"3. Chinh sua loai ve\n";
                cout<<"4. Xem danh sach da sap xep\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    ticketTypeList.inputTickettype();
                }else if(option1==2){
                    ticketTypeList.deleteTickettype();
                }else if(option1==3){
                    ticketTypeList.updateTickettype();
                }else if(option1==4){
                    ticketTypeList.sortName();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==4){
            int option1;
            do{
                tripList.showTrip(stationList);
                cout<<"==============================================\n";
                cout<<"1. Them luot di\n";
                cout<<"2. Xoa luot di\n";
                cout<<"3. Chinh sua luot di\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    tripList.inputTrip(stationList);
                }else if(option1==2){
                    tripList.deleteTrip();
                }else if(option1==3){
                    tripList.updateTrip(stationList);
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==5){
            int option1;
            do{
                stationList.showStation();
                cout<<"==============================================\n";
                cout<<"1. Them ga tau\n";
                cout<<"2. Xoa ga tau\n";
                cout<<"3. Chinh sua ga tau\n";
                cout<<"4. Xem danh sach da sap xep\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    stationList.inputStation();
                }else if(option1==2){
                    stationList.deleteStation();
                }else if(option1==3){
                    stationList.updateStation();
                }else if(option1==4){
                    stationList.sortName();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==6){
            int option1;
            do{
                transactionList.showTransaction();
                cout<<"==============================================\n";
                cout<<"1. Them giao dich\n";
                cout<<"2. Xoa giao dich\n";
                cout<<"3. Chinh sua giao dich\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    transactionList.inputTransaction();
                }else if(option1==2){
                    transactionList.deleteTransaction();
                }else if(option1==3){
                    transactionList.updateTransaction();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==7){
            int option1;
            do{
                staffList.showStaff();
                cout<<"==============================================\n";
                cout<<"1. Them nhan vien\n";
                cout<<"2. Xoa nhan vien\n";
                cout<<"3. Chinh sua nhan vien\n";
                cout<<"4. Xem danh sach da sep xep\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    staffList.inputStaff();
                }else if(option1==2){
                    staffList.deleteStaff();
                }else if(option1==3){
                    staffList.updateStaff();
                }else if(option1==4){
                    staffList.sortName();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==8){
            int option1;
            do{
                counterList.showCounter();
                cout<<"==============================================\n";
                cout<<"1. Them quay ban ve\n";
                cout<<"2. Xoa quay ban ve\n";
                cout<<"3. Chinh sua quay ban ve\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    counterList.inputCounter();
                }else if(option1==2){
                    counterList.deleteCounter();
                }else if(option1==3){
                    counterList.updateCounter();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==9){
            int option1;
            do{
                cout<<"==============================================\n";
                cout<<"1. Bat dau truy xuat\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    ticketList.printTicket(passengerList, 
                                    ticketTypeList, 
                                    tripList, 
                                    staffList, 
                                    counterList,
                                    stationList,
                                    ticketList);
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==10){
            ticketList.details(passengerList, ticketList, ticketTypeList, staffList, stationList);
        }else if(option==11){
            int option1;
            do{
                cout<<"==============================================\n";
                cout<<"|                MENU TIM KIEM               |\n";
                cout<<"==============================================\n";
                cout<<"1. Tim kiem hanh khach\n";
                cout<<"2. Tim kiem loai ve\n";
                cout<<"3. Tim kiem luot di\n";
                cout<<"4. Tim kiem ga tau\n";
                cout<<"5. Tim kiem giao dich\n";
                cout<<"6. Tim kiem nhan vien\n";
                cout<<"7. Tim kiem quay ban ve\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                int ID;
                if(option1==1){
                    int option2;
                    do{
                        cout<<"Nhap ID hanh khach can tim kiem: ";
                        cin>>ID;
                        Passenger *p=passengerList.searchPassenger(passengerList,ID);
                        if(p==NULL){
                            cout<<"Khong tim thay hanh khach !\n";
                        }else{
                            cout<<"Tim thay hanh khach !\n";
                            cout<<"=======================================\n";
                            cout<<"|         THONG TIN HANH KHACH        |\n";
                            cout<<"---------------------------------------\n";
                            cout<<"Ma hanh khach: "<<p->passengerID<<endl;
                            cout<<"Ten hanh khach: "<<p->passengerName<<endl;
                            cout<<"Ngay sinh: "<<p->birthDate<<endl;
                            cout<<"SDT: "<<p->phoneNumber<<endl;
                        }
                            cout<<"---------------------------------------\n";
                            cout<<"1. Tiep tuc tim kiem hanh khach\n";
                            cout<<"0. Thoat\n";
                            cout<<"=======================================\n";
                            cout<<"Chon: ";
                            cin>>option2;
                    }while(option2==1);
                }else if(option1==2){
                    int option2;
                    do{
                        cout<<"Nhap ID loai ve can tim kiem: ";
                        cin>>ID;
                        Tickettype *p=ticketTypeList.searchTickettype(ticketTypeList,ID);
                        if(p==NULL){
                            cout<<"Khong tim thay loai ve !\n";
                        }else{
                            cout<<"Tim thay loai ve !\n";
                            cout<<"=======================================\n";
                            cout<<"|         THONG TIN LOAI VE           |\n";
                            cout<<"---------------------------------------\n";
                            cout<<"Ma loai ve: "<<p->typeID<<endl;
                            cout<<"Ten loai ve: "<<p->typeName<<endl;
                            cout<<"Gia ban: "<<p->price<<endl;
                            cout<<"Mo ta: "<<p->description<<endl;
                        }
                            cout<<"---------------------------------------\n";
                            cout<<"1. Tiep tuc tim kiem loai ve\n";
                            cout<<"0. Thoat\n";
                            cout<<"=======================================\n";
                            cout<<"Chon: ";
                            cin>>option2;
                    }while(option2==2);
                }else if(option1==3){
                    int option2;
                    do{
                        cout<<"Nhap ID luot di can tim kiem: ";
                        cin>>ID;
                        Trip *p=tripList.searchTrip(tripList,ID);
                        if(p==NULL){
                            cout<<"Khong tim thay luot di !\n";
                        }else{
                            cout<<"Tim thay luot di !\n";
                            cout<<"=======================================\n";
                            cout<<"|         THONG TIN LUOT DI           |\n";
                            cout<<"---------------------------------------\n";
                            cout<<"Ma luot di: "<<p->tripID<<endl;
                            cout<<"Ma ve: "<<p->ticketID<<endl;
                            cout<<"Ga di: "<<p->goStation<<endl;
                            cout<<"Ga den: "<<p->arriveStation<<endl;
                            cout<<"Thoi gian di: "<<p->goTime<<endl;
                            cout<<"Thoi gian den: "<<p->arriveTime<<endl;
                        }
                            cout<<"---------------------------------------\n";
                            cout<<"1. Tiep tuc tim kiem luot di\n";
                            cout<<"0. Thoat\n";
                            cout<<"=======================================\n";
                            cout<<"Chon: ";
                            cin>>option2;
                    }while(option2==3);
                }else if(option1==4){
                    int option2;
                    do{
                        cout<<"Nhap ID ga tau can tim kiem: ";
                        cin>>ID;
                        Station *p=stationList.searchStation(stationList,ID);
                        if(p==NULL){
                            cout<<"Khong tim thay ga tau !\n";
                        }else{
                            cout<<"Tim thay ga tau !\n";
                            cout<<"=======================================\n";
                            cout<<"|         THONG TIN GA TAU            |\n";
                            cout<<"---------------------------------------\n";
                            cout<<"Ma ga: "<<p->stationID<<endl;
                            cout<<"Ten ga: "<<p->stationName<<endl;
                            cout<<"Dia chi ga: "<<p->address<<endl;
                        }
                            cout<<"---------------------------------------\n";
                            cout<<"1. Tiep tuc tim kiem ga tau\n";
                            cout<<"0. Thoat\n";
                            cout<<"=======================================\n";
                            cout<<"Chon: ";
                            cin>>option2;
                    }while(option2==4);
                }else if(option1==5){
                    int option2;
                    do{
                        cout<<"Nhap ID giao dich can tim kiem: ";
                        cin>>ID;
                        Transaction *p=transactionList.searchTransaction(transactionList,ID);
                        if(p==NULL){
                            cout<<"Khong tim thay giao dich !\n";
                        }else{
                            cout<<"Tim thay giao dich !\n";
                            cout<<"=======================================\n";
                            cout<<"|         THONG TIN GIAO DICH         |\n";
                            cout<<"---------------------------------------\n";
                            cout<<"Ma giao dich: "<<p->transactionID<<endl;
                            cout<<"Ma ve: "<<p->ticketID<<endl;
                            cout<<"Ten hanh khach: ";
                            Passenger *p1=passengerList.searchPassenger(passengerList,p->passengerID);
                            cout<<p1->passengerName<<endl;
                            cout<<"Thoi gian giao dich: "<<p->transactionTime<<endl;
                            cout<<"So tien thanh toan: "<<p->paidMoney<<endl;
                        }
                            cout<<"---------------------------------------\n";
                            cout<<"1. Tiep tuc tim kiem giao dich\n";
                            cout<<"0. Thoat\n";
                            cout<<"=======================================\n";
                            cout<<"Chon: ";
                            cin>>option2;
                    }while(option2==5);
                }else if(option1==6){
                    int option2;
                    do{
                        cout<<"Nhap ID nhan vien can tim kiem: ";
                        cin>>ID;
                        Staff *p=staffList.searchStaff(staffList,ID);
                        if(p==NULL){
                            cout<<"Khong tim thay nhan vien !\n";
                        }else{
                            cout<<"Tim thay nhan vien !\n";
                            cout<<"=======================================\n";
                            cout<<"|         THONG TIN NHAN VIEN         |\n";
                            cout<<"---------------------------------------\n";
                            cout<<"Ma nhan vien: "<<p->staffID<<endl;
                            cout<<"Ten nhan vien: "<<p->staffName<<endl;
                            cout<<"Ngay sinh: "<<p->staffBirthDate;
                            cout<<"SDT: "<<p->staffPhoneNumber<<endl;
                        }
                            cout<<"---------------------------------------\n";
                            cout<<"1. Tiep tuc tim kiem nhan vien\n";
                            cout<<"0. Thoat\n";
                            cout<<"=======================================\n";
                            cout<<"Chon: ";
                            cin>>option2;
                    }while(option2==6);
                }else if(option1==7){
                    int option2;
                    do{
                        cout<<"Nhap ID quay ban ve can tim kiem: ";
                        cin>>ID;
                        Counter *p=counterList.searchCounter(counterList,ID);
                        if(p==NULL){
                            cout<<"Khong tim thay quay ban ve !\n";
                        }else{
                            cout<<"Tim thay quay ban ve !\n";
                            cout<<"=======================================\n";
                            cout<<"|        THONG TIN QUAY BAN VE        |\n";
                            cout<<"---------------------------------------\n";
                            cout<<"Ma quay: "<<p->counterID<<endl;
                            cout<<"Vi tri quay: "<<p->counterLocation<<endl;
                        }
                            cout<<"---------------------------------------\n";
                            cout<<"1. Tiep tuc tim kiem quay ban ve\n";
                            cout<<"0. Thoat\n";
                            cout<<"=======================================\n";
                            cout<<"Chon: ";
                            cin>>option2;
                    }while(option2==7);
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option!=0){
            cout<<"╔═════════════════════════╗\n";
            cout<<"|  Cu phap khong hop le!  |\n";
            cout<<"╚═════════════════════════╝\n";
        }else{
            continue;
        }
    }while(option!=0);
}