#include "List.h"
int main(){
    List<Passenger> passengerList;
    List<Staff> staffList;
    List<Trip> tripList;
    List<Station> stationList;
    List<Tickettype> ticketTypeList;
    List<Ticket> ticketList;
    List<Counter> counterList;
    List<Transaction> transactionList;
    int option;
    do{
        cout<<"==============================================\n";
        cout<<"|   CHUONG TRINH QUAN LY VE TAU DIEN METRO   |\n";
        cout<<"==============================================\n";
        cout<<"|1. Xem hanh khach                           |\n";
        cout<<"|2. Xem ve                                   |\n";
        cout<<"|3. Xem loai ve                              |\n";
        cout<<"|4. Xem luot di                              |\n";
        cout<<"|5. Xem ga tau                               |\n";
        cout<<"|6. Xem giao dich                            |\n";
        cout<<"|7. Xem nhan vien                            |\n";
        cout<<"|8. Xem quay ban ve                          |\n";
        cout<<"|9. Truy xuat ve                             |\n";
        cout<<"|10. Thong ke                                |\n";
        cout<<"|0. Thoat                                    |\n";
        cout<<"==============================================\n";
        cout<<"Chon: ";
        cin>>option;
        if(option==1){
            int option1;
            do{
                passengerList.showPassenger();
                cout<<"==============================================\n";
                cout<<"1. Them hanh khach\n";
                cout<<"2. Xoa hanh khach\n";
                cout<<"3. Chinh sua hanh khach\n";
                cout<<"4. Xem danh sach da sap xep\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    passengerList.inputPassenger();
                }else if(option1==2){
                    passengerList.deletePassenger();
                }else if(option1==3){
                    passengerList.updatePassenger();
                }else if(option1==4){
                    passengerList.sortName();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==2){
            int option1;
            do{
                ticketList.showTicket(passengerList, 
                                    ticketTypeList, 
                                    tripList, 
                                    staffList, 
                                    counterList);
                cout<<"==============================================\n";
                cout<<"1. Them ve\n";
                cout<<"2. Xoa ve\n";
                cout<<"3. Chinh sua ve\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    ticketList.inputTicket(passengerList, 
                                            ticketTypeList, 
                                            tripList, 
                                            staffList, 
                                            counterList);
                }else if(option1==2){
                    ticketList.deleteTicket();
                }else if(option1==3){
                    ticketList.updateTicket(passengerList, 
                                            ticketTypeList, 
                                            tripList, 
                                            staffList, 
                                            counterList);
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==3){
            int option1;
            do{
                ticketTypeList.showTickettype();
                cout<<"==============================================\n";
                cout<<"1. Them loai ve\n";
                cout<<"2. Xoa loai ve\n";
                cout<<"3. Chinh sua loai ve\n";
                cout<<"4. Xem danh sach da sap xep\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    ticketTypeList.inputTickettype();
                }else if(option1==2){
                    ticketTypeList.deleteTickettype();
                }else if(option1==3){
                    ticketTypeList.updateTickettype();
                }else if(option1==4){
                    ticketTypeList.sortName();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==4){
            int option1;
            do{
                tripList.showTrip(stationList);
                cout<<"==============================================\n";
                cout<<"1. Them luot di\n";
                cout<<"2. Xoa luot di\n";
                cout<<"3. Chinh sua luot di\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    tripList.inputTrip(stationList);
                }else if(option1==2){
                    tripList.deleteTrip();
                }else if(option1==3){
                    tripList.updateTrip(stationList);
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==5){
            int option1;
            do{
                stationList.showStation();
                cout<<"==============================================\n";
                cout<<"1. Them ga tau\n";
                cout<<"2. Xoa ga tau\n";
                cout<<"3. Chinh sua ga tau\n";
                cout<<"4. Xem danh sach da sap xep\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    stationList.inputStation();
                }else if(option1==2){
                    stationList.deleteStation();
                }else if(option1==3){
                    stationList.updateStation();
                }else if(option1==4){
                    stationList.sortName();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==6){
            int option1;
            do{
                transactionList.showTransaction();
                cout<<"==============================================\n";
                cout<<"1. Them giao dich\n";
                cout<<"2. Xoa giao dich\n";
                cout<<"3. Chinh sua giao dich\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    transactionList.inputTransaction();
                }else if(option1==2){
                    transactionList.deleteTransaction();
                }else if(option1==3){
                    transactionList.updateTransaction();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==7){
            int option1;
            do{
                staffList.showStaff();
                cout<<"==============================================\n";
                cout<<"1. Them nhan vien\n";
                cout<<"2. Xoa nhan vien\n";
                cout<<"3. Chinh sua nhan vien\n";
                cout<<"4. Xem danh sach da sep xep\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    staffList.inputStaff();
                }else if(option1==2){
                    staffList.deleteStaff();
                }else if(option1==3){
                    staffList.updateStaff();
                }else if(option1==4){
                    staffList.sortName();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==8){
            int option1;
            do{
                counterList.showCounter();
                cout<<"==============================================\n";
                cout<<"1. Them quay ban ve\n";
                cout<<"2. Xoa quay ban ve\n";
                cout<<"3. Chinh sua quay ban ve\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    counterList.inputCounter();
                }else if(option1==2){
                    counterList.deleteCounter();
                }else if(option1==3){
                    counterList.updateCounter();
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==9){
            int option1;
            do{
                cout<<"==============================================\n";
                cout<<"1. Bat dau truy xuat\n";
                cout<<"0.Thoat\n";
                cout<<"==============================================\n";
                cout<<"Chon: ";
                cin>>option1;
                if(option1==1){
                    ticketList.printTicket(passengerList, 
                                    ticketTypeList, 
                                    tripList, 
                                    staffList, 
                                    counterList,
                                    stationList,
                                    ticketList);
                }else if(option1!=0){
                    cout<<"╔═════════════════════════╗\n";
                    cout<<"|  Cu phap khong hop le!  |\n";
                    cout<<"╚═════════════════════════╝\n";
                }else{
                    continue;
                }
            }while(option1!=0);
        }else if(option==10){
            ticketList.details(passengerList, ticketList, ticketTypeList, staffList, stationList);
        }else if(option!=0){
            cout<<"╔═════════════════════════╗\n";
            cout<<"|  Cu phap khong hop le!  |\n";
            cout<<"╚═════════════════════════╝\n";
        }else{
            continue;
        }
    }while(option!=0);
}