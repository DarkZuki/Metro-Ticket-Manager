#ifndef STRUCTS_H
#define STRUCTS_H
#include <string>
using namespace std;
struct Passenger{
    int passengerID;
    string passengerName;
    string birthDate;
    string phoneNumber;
    string name() const{
        return passengerName;
    }
    Passenger *next;
};
struct Tickettype{
    int typeID;
    string typeName;
    double price;
    string description;
    string name() const{
        return typeName;
    }
    Tickettype *next;
};
struct Station{
    int stationID;
    string stationName;
    string address;
    string name() const{
        return stationName;
    }
    Station *next;
};
struct Trip{
    int tripID;
    int ticketID;
    int goStationID;
    int arriveStationID;
    Station *goStation;
    Station *arriveStation;
    string goTime;
    string arriveTime;
    Trip *next;
};
struct Transaction{
    int transactionID;
    int passengerID;
    int ticketID;
    string transactionTime;
    double paidMoney;
    Transaction *next;
};
struct Staff{
    int staffID;
    string staffName;
    string staffBirthDate;
    string staffPhoneNumber;
    string name() const{
        return staffName;
    }
    Staff *next;
};
struct Counter{
    int counterID;
    string counterLocation;
    Counter *next;
};
struct Ticket{
    int ticketID;
    int passengerID;
    int ticketTypeID;
    int tripID;
    int staffID;
    int counterID;
    Passenger *passenger;
    Tickettype *tickettype;
    Trip *trip;
    string issueTime;
    string expireTime;
    Staff *staff;
    Counter *counter;
    string status;
    Ticket *next;
};
#endif